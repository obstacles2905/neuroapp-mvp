import { Delegate, type MediaPipeSolution, RunningMode, type Landmark, type Mask, type DetectionError, type DetectionResultBundle, type DetectionCallbacks, type ResizeMode, type ImageOrientation, type ViewCoordinator } from './shared/types';
export { MediapipeCamera, type MediapipeCameraProps, } from './shared/mediapipeCamera';
export { Delegate, RunningMode, type MediaPipeSolution };
export type { Landmark, Mask, ResizeMode, ImageOrientation, DetectionError, DetectionCallbacks, ViewCoordinator, };
export { BaseViewCoordinator } from './shared/convert';
export interface PoseLandmarkerResult {
    landmarks: Landmark[][];
    worldLandmarks: Landmark[][];
    segmentationMasks: Mask[];
}
export type PoseDetectionResultBundle = DetectionResultBundle<PoseLandmarkerResult>;
type FpsMode = 'none' | number;
export interface PoseDetectionOptions {
    numPoses: number;
    minPoseDetectionConfidence: number;
    minPosePresenceConfidence: number;
    minTrackingConfidence: number;
    shouldOutputSegmentationMasks: boolean;
    delegate: Delegate;
    mirrorMode: 'no-mirror' | 'mirror' | 'mirror-front-only';
    forceOutputOrientation: ImageOrientation;
    forceCameraOrientation: ImageOrientation;
    fpsMode: FpsMode;
}
export declare function usePoseDetection(callbacks: DetectionCallbacks<PoseDetectionResultBundle>, runningMode: RunningMode, model: string, options?: Partial<PoseDetectionOptions>): MediaPipeSolution;
export declare function PoseDetectionOnImage(imagePath: string, model: string, options?: Partial<PoseDetectionOptions>): Promise<PoseDetectionResultBundle>;
export declare const KnownPoseLandmarks: {
    nose: number;
    leftEyeInner: number;
    leftEye: number;
    leftEyeOuter: number;
    rightEyeInner: number;
    rightEye: number;
    rightEyeOuter: number;
    leftEar: number;
    rightEar: number;
    mouthLeft: number;
    mouthRight: number;
    leftShoulder: number;
    rightShoulder: number;
    leftElbow: number;
    rightElbow: number;
    leftWrist: number;
    rightWrist: number;
    leftPinky: number;
    rightPinky: number;
    leftIndex: number;
    rightIndex: number;
    leftThumb: number;
    rightThumb: number;
    leftHip: number;
    rightHip: number;
    leftKnee: number;
    rightKnee: number;
    leftAnkle: number;
    rightAnkle: number;
    leftHeel: number;
    rightHeel: number;
    leftFootIndex: number;
    rightFootIndex: number;
};
export declare const KnownPoseLandmarkConnections: number[][];
//# sourceMappingURL=index.d.ts.map