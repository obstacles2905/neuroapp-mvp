import { type ConfigPlugin } from '@expo/config-plugins';
import type { MediapipePluginProps } from './PluginProps';
/**
 * iOS-specific config plugin to copy assets to iOS project with Xcode references
 */
export declare const withAssets: ConfigPlugin<MediapipePluginProps>;
export declare const ios: {
    withAssets: ConfigPlugin<MediapipePluginProps>;
};
//# sourceMappingURL=ios.d.ts.map