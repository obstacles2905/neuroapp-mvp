import { type ConfigPlugin } from '@expo/config-plugins';
import type { MediapipePluginProps } from './PluginProps';
/**
 * Android-specific config plugin to copy assets to android/app/src/main/assets/
 */
export declare const withAssets: ConfigPlugin<MediapipePluginProps>;
export declare const android: {
    withAssets: ConfigPlugin<MediapipePluginProps>;
};
//# sourceMappingURL=android.d.ts.map