import { type ConfigPlugin } from '@expo/config-plugins';
import type { MediapipePluginProps } from './PluginProps';
declare const _default: ConfigPlugin<MediapipePluginProps>;
export default _default;
//# sourceMappingURL=withMediapipePosedetection.d.ts.map